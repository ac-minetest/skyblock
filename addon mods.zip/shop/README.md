# shop by everamzah
gui cleanup and enhancements by rnd
License GPL3
