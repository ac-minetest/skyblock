# Compost Mod
With this mod, you are able to compost grass, leaves, flowers...

## License
see LICENSE.txt

## Crafting
Wood barrel:

| W |   | W |
|---|---|---|
| W |   | W |
| W | S | W |

W : wood
S : wood slab

## Bugs
Report bugs on the forum topic or open a issue on GitHub.

## created by
cd2 (cdqwertz) - cdqwertz.github.io
