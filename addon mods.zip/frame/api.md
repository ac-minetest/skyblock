
## frame API

`frame.register(name)` --[[
^ name = node or item name, e.g. "default:sapling" or "default:sword_diamond"
^ the node must be defined and registered first using `minetest.register_node()`. ]]

